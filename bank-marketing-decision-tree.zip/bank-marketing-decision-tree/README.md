# 🌳 Bank Marketing Decision Tree Classifier

![Python](https://img.shields.io/badge/Python-3.8%2B-blue?logo=python&logoColor=white)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.0%2B-orange?logo=scikit-learn&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green)
![Status](https://img.shields.io/badge/Status-Active-brightgreen)

> Predict whether a bank customer will subscribe to a **term deposit** using a Decision Tree Classifier trained on the UCI Bank Marketing dataset.

---

## 📋 Table of Contents

- [Overview](#-overview)
- [Dataset](#-dataset)
- [Project Structure](#-project-structure)
- [Installation](#-installation)
- [Usage](#-usage)
- [Results](#-results)
- [Visualizations](#-visualizations)
- [Features](#-features)
- [Contributing](#-contributing)
- [License](#-license)

---

## 🔍 Overview

This project implements a full machine learning pipeline to classify whether a bank client will subscribe to a term deposit product. It covers:

- Data generation matching the **UCI Bank Marketing** schema
- Feature engineering & preprocessing
- Handling class imbalance via oversampling
- Hyperparameter tuning with `GridSearchCV`
- Model evaluation with multiple metrics
- Rich visualizations (9-panel dashboard)

**Reference:** Moro, S., Cortez, P., & Rita, P. (2014). *A data-driven approach to predict the success of bank telemarketing.* Decision Support Systems.  
**Dataset:** [UCI ML Repository – Bank Marketing](https://archive.ics.uci.edu/dataset/222/bank+marketing)

---

## 📊 Dataset

The UCI Bank Marketing dataset contains results of direct marketing campaigns (phone calls) of a Portuguese banking institution.

| Property | Details |
|----------|---------|
| Records  | 45,211 (full) / 41,188 (additional) |
| Features | 20 input features |
| Target   | Binary: `yes` / `no` (subscribed to term deposit) |
| Class Balance | ~88.7% No, ~11.3% Yes |

### Feature Groups

**Client Demographics**
| Feature | Type | Description |
|---------|------|-------------|
| `age` | Numeric | Client age |
| `job` | Categorical | Type of job (12 categories) |
| `marital` | Categorical | Marital status |
| `education` | Categorical | Education level |
| `default` | Categorical | Has credit in default? |
| `housing` | Categorical | Has housing loan? |
| `loan` | Categorical | Has personal loan? |

**Campaign Information**
| Feature | Type | Description |
|---------|------|-------------|
| `contact` | Categorical | Contact communication type |
| `month` | Categorical | Last contact month |
| `day_of_week` | Categorical | Last contact day |
| `duration` | Numeric | Last contact duration (seconds) |
| `campaign` | Numeric | Number of contacts in this campaign |
| `pdays` | Numeric | Days since last contact (999 = not contacted) |
| `previous` | Numeric | Number of previous contacts |
| `poutcome` | Categorical | Outcome of previous campaign |

**Macroeconomic Indicators**
| Feature | Type | Description |
|---------|------|-------------|
| `emp_var_rate` | Numeric | Employment variation rate |
| `cons_price_idx` | Numeric | Consumer price index |
| `cons_conf_idx` | Numeric | Consumer confidence index |
| `euribor3m` | Numeric | Euribor 3-month rate |
| `nr_employed` | Numeric | Number of employees |

---

## 📁 Project Structure

```
bank-marketing-decision-tree/
│
├── README.md                    # This file
├── requirements.txt             # Python dependencies
├── .gitignore                   # Git ignore rules
├── LICENSE                      # MIT License
│
├── src/
│   ├── __init__.py
│   ├── data_generator.py        # Synthetic UCI-schema data generation
│   ├── preprocessor.py          # Feature encoding & train/test split
│   ├── model.py                 # Decision tree training & tuning
│   └── evaluate.py              # Metrics & evaluation utilities
│
├── notebooks/
│   └── bank_marketing_analysis.ipynb   # Full walkthrough notebook
│
├── data/
│   └── README.md                # Instructions to download UCI data
│
├── results/
│   └── bank_decision_tree_results.png  # Output visualization dashboard
│
├── tests/
│   ├── test_preprocessor.py
│   └── test_model.py
│
└── main.py                      # End-to-end pipeline entry point
```

---

## ⚙️ Installation

### Prerequisites
- Python 3.8+
- pip

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/bank-marketing-decision-tree.git
cd bank-marketing-decision-tree

# 2. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # macOS/Linux
venv\Scripts\activate           # Windows

# 3. Install dependencies
pip install -r requirements.txt
```

---

## 🚀 Usage

### Run the full pipeline

```bash
python main.py
```

This will:
1. Generate a 10,000-row synthetic dataset (UCI schema)
2. Preprocess and balance the data
3. Run `GridSearchCV` for hyperparameter tuning
4. Train the final Decision Tree
5. Evaluate on the test set
6. Save a 9-panel visualization to `results/`

### Use your own UCI data

Download the dataset from the [UCI Repository](https://archive.ics.uci.edu/dataset/222/bank+marketing) and place `bank-additional-full.csv` in the `data/` folder, then run:

```bash
python main.py --data data/bank-additional-full.csv
```

### Import as a module

```python
from src.data_generator import generate_bank_data
from src.preprocessor import preprocess
from src.model import train_decision_tree
from src.evaluate import evaluate_model

# Generate / load data
df = generate_bank_data(n=10000)

# Preprocess
X_train, X_test, y_train, y_test, feature_names = preprocess(df)

# Train
model, best_params = train_decision_tree(X_train, y_train)

# Evaluate
metrics = evaluate_model(model, X_test, y_test)
print(metrics)
```

---

## 📈 Results

### Best Hyperparameters (GridSearchCV, 5-fold CV)

| Parameter | Value |
|-----------|-------|
| Criterion | Gini |
| Max Depth | 10 |
| Min Samples Split | 10 |
| Min Samples Leaf | 5 |
| Class Weight | Balanced |

### Performance Metrics

| Metric | Score |
|--------|-------|
| **Accuracy** | 0.778 |
| **Precision** (Purchase) | 0.177 |
| **Recall** (Purchase) | 0.439 |
| **F1-Score** (Purchase) | 0.253 |
| **ROC-AUC** | 0.598 |
| **CV AUC (5-fold)** | **0.880 ± 0.003** |

### Top 5 Most Important Features

| Rank | Feature | Importance |
|------|---------|-----------|
| 1 | `duration` | 0.284 |
| 2 | `emp_var_rate` | 0.140 |
| 3 | `cons_price_idx` | 0.100 |
| 4 | `poutcome` | 0.097 |
| 5 | `cons_conf_idx` | 0.083 |

> **Note on class imbalance:** The dataset is imbalanced (~8.6% positive class). Accuracy alone is misleading — focus on Recall and ROC-AUC for business-relevant evaluation.

---

## 🖼️ Visualizations

The pipeline generates a 9-panel dashboard saved to `results/bank_decision_tree_results.png`:

| Panel | Content |
|-------|---------|
| A | Class distribution (bar chart) |
| B | Age distribution by outcome |
| C | Purchase rate by job category |
| D | Confusion matrix |
| E | ROC curve |
| F | Feature importances (top 15) |
| G | Decision tree visualization (depth = 3) |
| H | 5-fold cross-validation AUC scores |
| I | Age vs. call duration scatter plot |
| J | Model performance summary card |

---

## 🤝 Contributing

Contributions are welcome! Here's how:

```bash
# Fork the repo, then:
git checkout -b feature/your-feature-name
git commit -m "Add your feature"
git push origin feature/your-feature-name
# Open a Pull Request
```

Please ensure:
- Code follows PEP 8
- New features include tests in `tests/`
- The README is updated if needed

---

## 📄 License

This project is licensed under the **MIT License** — see [LICENSE](LICENSE) for details.

---

## 🙏 Acknowledgements

- [UCI Machine Learning Repository](https://archive.ics.uci.edu/dataset/222/bank+marketing) for the dataset
- Moro, S., Cortez, P., & Rita, P. (2014) for the original research
- [scikit-learn](https://scikit-learn.org/) for the ML tools
